<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Confirmation</title>
</head>
<body>
    <h1>Apartment System</h1>
    <p>Hello, Thank you for contacting us! We have received your message:</p>
    <p>We will get back to you shortly.</p>
    <p>Best Regards,<br>Apartment System</p>
</body>
</html>
