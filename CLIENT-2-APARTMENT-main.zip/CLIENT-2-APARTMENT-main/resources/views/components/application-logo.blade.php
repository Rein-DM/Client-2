<div class="flex justify-center items-center py-4">
    <img src="{{ asset('admin_assets/assets/images/logo/logo.png') }}" alt="Logo"
         class="w-20 h-20 object-contain rounded-full">
</div>
